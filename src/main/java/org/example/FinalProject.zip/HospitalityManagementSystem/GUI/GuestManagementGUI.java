package org.example.HospitalityManagementSystem.GUI;

import org.example.HospitalityManagementSystem.ClassEntity.Guest;
import org.example.HospitalityManagementSystem.Implements.GuestDaoImp;
import org.example.HospitalityManagementSystem.InterfaceDao.GuestDao;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GuestManagementGUI extends JFrame {
    public GuestManagementGUI(){
        setTitle("ADD Guest");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        GuestDao guestDao = new GuestDaoImp();

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        panel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Email:"));
        JTextField emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Phone Number:"));
        JTextField phoneNumberField = new JTextField();
        panel.add(phoneNumberField);

        JButton addButton = new JButton("Add Guest");
        panel.add(addButton);

        add(panel);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String email = emailField.getText();
                String phoneNumber = phoneNumberField.getText();

                Guest guest = new Guest(0, name, email, phoneNumber);
                guestDao.addGuest(guest);

                JOptionPane.showMessageDialog(null, "Guest added successfully.");
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GuestManagementGUI().setVisible(true);
            }
        });
    }
}
